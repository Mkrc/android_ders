package com.example.nazan.aralik_2;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Nazan on 8.12.2016.
 */

public class Yeni extends Activity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.yeni);
    }

}
